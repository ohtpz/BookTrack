-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: Booktrack
-- ------------------------------------------------------
-- Server version	5.5.5-10.11.11-MariaDB-0ubuntu0.24.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Avis`
--

DROP TABLE IF EXISTS `Avis`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Avis` (
  `idAvis` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `note` enum('1','2','3','4','5') NOT NULL,
  `commentaire` text NOT NULL,
  `date` datetime NOT NULL,
  `idUtilisateur` int(10) unsigned NOT NULL,
  `idLivre` int(10) unsigned NOT NULL,
  PRIMARY KEY (`idAvis`),
  KEY `Avis_Livre_FK` (`idLivre`),
  KEY `Avis_Utilisateur_FK` (`idUtilisateur`),
  CONSTRAINT `Avis_Livre_FK` FOREIGN KEY (`idLivre`) REFERENCES `Livre` (`idLivre`),
  CONSTRAINT `Avis_Utilisateur_FK` FOREIGN KEY (`idUtilisateur`) REFERENCES `Utilisateur` (`idUtilisateur`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Avis`
--

LOCK TABLES `Avis` WRITE;
/*!40000 ALTER TABLE `Avis` DISABLE KEYS */;
/*!40000 ALTER TABLE `Avis` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Bibliotheque`
--

DROP TABLE IF EXISTS `Bibliotheque`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Bibliotheque` (
  `idBiblio` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `idUtilisateur` int(10) unsigned NOT NULL,
  PRIMARY KEY (`idBiblio`),
  KEY `Bibliotheque_Utilisateur_FK` (`idUtilisateur`),
  CONSTRAINT `Bibliotheque_Utilisateur_FK` FOREIGN KEY (`idUtilisateur`) REFERENCES `Utilisateur` (`idUtilisateur`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Bibliotheque`
--

LOCK TABLES `Bibliotheque` WRITE;
/*!40000 ALTER TABLE `Bibliotheque` DISABLE KEYS */;
/*!40000 ALTER TABLE `Bibliotheque` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Emprunt`
--

DROP TABLE IF EXISTS `Emprunt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Emprunt` (
  `idEmprunt` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `dateDebut` date NOT NULL,
  `dateFin` date NOT NULL,
  `statut` enum('attente','en cours','à rendre','rendu') NOT NULL DEFAULT 'attente',
  `idLivre` int(10) unsigned NOT NULL,
  `idEmprunteur` int(10) unsigned NOT NULL,
  `idProprietaire` int(10) unsigned NOT NULL,
  PRIMARY KEY (`idEmprunt`),
  KEY `Emprunt_Livre_FK` (`idLivre`),
  KEY `Emprunt_Utilisateur_FK` (`idEmprunteur`),
  KEY `Emprunt_Utilisateur_FK_1` (`idProprietaire`),
  CONSTRAINT `Emprunt_Livre_FK` FOREIGN KEY (`idLivre`) REFERENCES `Livre` (`idLivre`),
  CONSTRAINT `Emprunt_Utilisateur_FK` FOREIGN KEY (`idEmprunteur`) REFERENCES `Utilisateur` (`idUtilisateur`),
  CONSTRAINT `Emprunt_Utilisateur_FK_1` FOREIGN KEY (`idProprietaire`) REFERENCES `Utilisateur` (`idUtilisateur`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Emprunt`
--

LOCK TABLES `Emprunt` WRITE;
/*!40000 ALTER TABLE `Emprunt` DISABLE KEYS */;
/*!40000 ALTER TABLE `Emprunt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Genre`
--

DROP TABLE IF EXISTS `Genre`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Genre` (
  `idGenre` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  PRIMARY KEY (`idGenre`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Genre`
--

LOCK TABLES `Genre` WRITE;
/*!40000 ALTER TABLE `Genre` DISABLE KEYS */;
/*!40000 ALTER TABLE `Genre` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Livre`
--

DROP TABLE IF EXISTS `Livre`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Livre` (
  `idLivre` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `titre` varchar(100) NOT NULL,
  `ISBN` varchar(255) NOT NULL,
  `illustration` blob DEFAULT NULL,
  `dateParution` date NOT NULL,
  `statutLecture` enum('aucun','en cours','lu') NOT NULL DEFAULT 'aucun',
  PRIMARY KEY (`idLivre`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Livre`
--

LOCK TABLES `Livre` WRITE;
/*!40000 ALTER TABLE `Livre` DISABLE KEYS */;
/*!40000 ALTER TABLE `Livre` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Livre_Bibliotheque`
--

DROP TABLE IF EXISTS `Livre_Bibliotheque`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Livre_Bibliotheque` (
  `idLivre` int(10) unsigned NOT NULL,
  `idBiblio` int(10) unsigned NOT NULL,
  PRIMARY KEY (`idLivre`,`idBiblio`),
  KEY `Livre_Bibliotheque_Bibliotheque_FK` (`idBiblio`),
  CONSTRAINT `Livre_Bibliotheque_Bibliotheque_FK` FOREIGN KEY (`idBiblio`) REFERENCES `Bibliotheque` (`idBiblio`),
  CONSTRAINT `Livre_Bibliotheque_Livre_FK` FOREIGN KEY (`idLivre`) REFERENCES `Livre` (`idLivre`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Livre_Bibliotheque`
--

LOCK TABLES `Livre_Bibliotheque` WRITE;
/*!40000 ALTER TABLE `Livre_Bibliotheque` DISABLE KEYS */;
/*!40000 ALTER TABLE `Livre_Bibliotheque` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Livre_Genre`
--

DROP TABLE IF EXISTS `Livre_Genre`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Livre_Genre` (
  `idLivre` int(10) unsigned NOT NULL,
  `idGenre` int(10) unsigned NOT NULL,
  PRIMARY KEY (`idLivre`,`idGenre`),
  KEY `Livre_Genre_Genre_FK` (`idGenre`),
  CONSTRAINT `Livre_Genre_Genre_FK` FOREIGN KEY (`idGenre`) REFERENCES `Genre` (`idGenre`),
  CONSTRAINT `Livre_Genre_Livre_FK` FOREIGN KEY (`idLivre`) REFERENCES `Livre` (`idLivre`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Livre_Genre`
--

LOCK TABLES `Livre_Genre` WRITE;
/*!40000 ALTER TABLE `Livre_Genre` DISABLE KEYS */;
/*!40000 ALTER TABLE `Livre_Genre` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Utilisateur`
--

DROP TABLE IF EXISTS `Utilisateur`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Utilisateur` (
  `idUtilisateur` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mdpHash` varchar(255) NOT NULL,
  `prenom` varchar(100) NOT NULL,
  `imageProfil` varchar(255) DEFAULT NULL,
  `role` enum('utilisateur','admin') NOT NULL DEFAULT 'utilisateur',
  PRIMARY KEY (`idUtilisateur`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Utilisateur`
--

LOCK TABLES `Utilisateur` WRITE;
/*!40000 ALTER TABLE `Utilisateur` DISABLE KEYS */;
/*!40000 ALTER TABLE `Utilisateur` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'Booktrack'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-09 15:54:05
